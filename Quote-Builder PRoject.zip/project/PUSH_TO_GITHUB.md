# Push para GitHub - Quote Builder

Siga estes passos para enviar o código para o repositório correto:

## 1. Abra o terminal na pasta do projeto

## 2. Execute os seguintes comandos:

```bash
# Inicializar repositório Git
git init

# Configurar identidade (opcional, ajuste com seus dados)
git config user.email "seu-email@exemplo.com"
git config user.name "Seu Nome"

# Adicionar todos os arquivos
git add .

# Fazer o commit inicial
git commit -m "All Ranks Quote Builder - Complete Application"

# Renomear branch para main
git branch -M main

# Adicionar o repositório remoto correto
git remote add origin https://github.com/pedroleiteaus-droid/Quote-Builder.git

# Enviar para o GitHub (forçar push para sobrescrever se necessário)
git push -u origin main --force
```

## 3. Autenticação

Quando solicitado, forneça suas credenciais do GitHub:
- **Username**: pedroleiteaus-droid
- **Password**: Use um Personal Access Token (não a senha da conta)

### Como criar um Personal Access Token:
1. Vá para: https://github.com/settings/tokens
2. Clique em "Generate new token" → "Generate new token (classic)"
3. Dê um nome (ex: "Quote Builder")
4. Selecione o escopo: `repo` (acesso completo aos repositórios)
5. Clique em "Generate token"
6. Copie o token e use como senha

## 4. Verificar

Depois do push, acesse:
https://github.com/pedroleiteaus-droid/Quote-Builder

E confirme que todos os arquivos estão lá!

---

## Notas Importantes:

- O arquivo `.env` NÃO será enviado (está no .gitignore por segurança)
- Apenas o `.env.example` será enviado
- Você precisará configurar as variáveis de ambiente no Netlify ou Vercel para o deploy
