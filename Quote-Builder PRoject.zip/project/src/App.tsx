import { useState } from 'react';
import { FileText, DollarSign, List } from 'lucide-react';
import RatesManager from './components/RatesManager';
import QuoteBuilder from './components/QuoteBuilder';
import QuotesList from './components/QuotesList';

type Tab = 'create' | 'rates' | 'history';

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('create');
  const [selectedQuoteId, setSelectedQuoteId] = useState<string | undefined>();

  const handleQuoteSaved = () => {
    setActiveTab('history');
    setSelectedQuoteId(undefined);
  };

  const handleSelectQuote = (quoteId: string) => {
    setSelectedQuoteId(quoteId);
    setActiveTab('create');
  };

  const handleNewQuote = () => {
    setSelectedQuoteId(undefined);
    setActiveTab('create');
  };

  return (
    <div className="min-h-screen bg-[#2C2C2C]">
      <header className="bg-[#1E1E1E] shadow-lg border-b-2 border-[#8BC34A]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <img
                src="/All Ranks Logo verde copy.jpg"
                alt="All Ranks Logo"
                className="h-16 w-auto"
              />
              <div>
                <h1 className="text-3xl font-bold text-white uppercase tracking-tight">
                  ALL RANKS EVENTS
                </h1>
                <p className="text-sm text-[#8BC34A] font-medium uppercase tracking-wide">
                  Quote Builder
                </p>
              </div>
            </div>
            {activeTab !== 'create' && (
              <button
                onClick={handleNewQuote}
                className="inline-flex items-center gap-2 px-6 py-3 bg-[#8BC34A] text-[#1E1E1E] rounded-lg hover:bg-[#7CB342] transition-colors font-bold shadow-sm uppercase tracking-wide"
              >
                <FileText size={20} />
                New Quote
              </button>
            )}
          </div>
        </div>
      </header>

      <nav className="bg-[#1E1E1E] border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8">
            <button
              onClick={() => {
                setSelectedQuoteId(undefined);
                setActiveTab('create');
              }}
              className={`flex items-center gap-2 py-4 px-1 border-b-2 font-bold text-sm transition-colors uppercase tracking-wide ${
                activeTab === 'create'
                  ? 'border-[#8BC34A] text-[#8BC34A]'
                  : 'border-transparent text-gray-400 hover:text-gray-200 hover:border-gray-600'
              }`}
            >
              <FileText size={18} />
              Create Quote
            </button>
            <button
              onClick={() => setActiveTab('rates')}
              className={`flex items-center gap-2 py-4 px-1 border-b-2 font-bold text-sm transition-colors uppercase tracking-wide ${
                activeTab === 'rates'
                  ? 'border-[#8BC34A] text-[#8BC34A]'
                  : 'border-transparent text-gray-400 hover:text-gray-200 hover:border-gray-600'
              }`}
            >
              <DollarSign size={18} />
              Manage Rates
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`flex items-center gap-2 py-4 px-1 border-b-2 font-bold text-sm transition-colors uppercase tracking-wide ${
                activeTab === 'history'
                  ? 'border-[#8BC34A] text-[#8BC34A]'
                  : 'border-transparent text-gray-400 hover:text-gray-200 hover:border-gray-600'
              }`}
            >
              <List size={18} />
              Quotes History
            </button>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'create' && (
          <QuoteBuilder quoteId={selectedQuoteId} onSaved={handleQuoteSaved} />
        )}
        {activeTab === 'rates' && <RatesManager />}
        {activeTab === 'history' && <QuotesList onSelectQuote={handleSelectQuote} />}
      </main>

      <footer className="bg-[#1E1E1E] border-t-2 border-[#8BC34A] mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <p className="text-center text-sm text-gray-400 uppercase tracking-wide">
            All Ranks Constructions Quote Builder - Internal Tool
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;
