export function formatDateToDDMMYYYY(date: string | null): string {
  if (!date) return '';
  const d = new Date(date);
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  return `${day}/${month}/${year}`;
}

export function formatDateInputToDDMMYYYY(dateString: string): string {
  if (!dateString) return '';
  const [year, month, day] = dateString.split('-');
  return `${day}/${month}/${year}`;
}

export function convertDDMMYYYYToInputFormat(ddmmyyyy: string): string {
  if (!ddmmyyyy) return '';
  const [day, month, year] = ddmmyyyy.split('/');
  return `${year}-${month}-${day}`;
}

const NSW_PUBLIC_HOLIDAYS_2024 = [
  '2024-01-01', // New Year's Day
  '2024-01-26', // Australia Day
  '2024-03-29', // Good Friday
  '2024-03-30', // Saturday before Easter Sunday
  '2024-04-01', // Easter Monday
  '2024-04-25', // Anzac Day
  '2024-06-10', // Queen's Birthday
  '2024-08-05', // Bank Holiday
  '2024-10-07', // Labour Day
  '2024-12-25', // Christmas Day
  '2024-12-26', // Boxing Day
];

const NSW_PUBLIC_HOLIDAYS_2025 = [
  '2025-01-01', // New Year's Day
  '2025-01-27', // Australia Day (observed)
  '2025-04-18', // Good Friday
  '2025-04-19', // Saturday before Easter Sunday
  '2025-04-21', // Easter Monday
  '2025-04-25', // Anzac Day
  '2025-06-09', // Queen's Birthday
  '2025-08-04', // Bank Holiday
  '2025-10-06', // Labour Day
  '2025-12-25', // Christmas Day
  '2025-12-26', // Boxing Day
];

const NSW_PUBLIC_HOLIDAYS = [...NSW_PUBLIC_HOLIDAYS_2024, ...NSW_PUBLIC_HOLIDAYS_2025];

export function isNSWPublicHoliday(dateString: string): boolean {
  return NSW_PUBLIC_HOLIDAYS.includes(dateString);
}

export type RateType = 'standard' | 'penalty' | 'holiday';

export interface SplitHours {
  standardHours: number;
  penaltyHours: number;
  holidayHours: number;
}

export function calculateSplitHours(
  dateString: string,
  startTime: string,
  finishTime: string,
  breakHours: number = 0
): SplitHours {
  if (!dateString || !startTime || !finishTime) {
    return { standardHours: 0, penaltyHours: 0, holidayHours: 0 };
  }

  const isHoliday = isNSWPublicHoliday(dateString);
  const date = new Date(dateString);
  const dayOfWeek = date.getDay();
  const isSunday = dayOfWeek === 0;

  const startHour = parseInt(startTime.split(':')[0]);
  const startMinute = parseInt(startTime.split(':')[1]);
  const finishHour = parseInt(finishTime.split(':')[0]);
  const finishMinute = parseInt(finishTime.split(':')[1]);

  const startMinutes = startHour * 60 + startMinute;
  const finishMinutes = finishHour * 60 + finishMinute;

  const totalMinutes = finishMinutes > startMinutes
    ? finishMinutes - startMinutes
    : (24 * 60 - startMinutes) + finishMinutes;

  const totalHours = totalMinutes / 60 - breakHours;

  if (isHoliday) {
    return { standardHours: 0, penaltyHours: 0, holidayHours: totalHours };
  }

  if (isSunday) {
    return { standardHours: 0, penaltyHours: totalHours, holidayHours: 0 };
  }

  const standardStart = 6 * 60;
  const standardEnd = 18 * 60;

  let standardMinutes = 0;
  let penaltyMinutes = 0;

  if (finishMinutes <= startMinutes) {
    const minutesBeforeMidnight = 24 * 60 - startMinutes;
    const minutesAfterMidnight = finishMinutes;

    if (startMinutes < standardEnd) {
      const beforeMidnightStandard = Math.min(minutesBeforeMidnight, standardEnd - startMinutes);
      standardMinutes += beforeMidnightStandard;
      penaltyMinutes += minutesBeforeMidnight - beforeMidnightStandard;
    } else {
      penaltyMinutes += minutesBeforeMidnight;
    }

    if (finishMinutes > standardStart) {
      penaltyMinutes += Math.min(finishMinutes, standardStart);
      if (finishMinutes <= standardEnd) {
        standardMinutes += finishMinutes - standardStart;
      } else {
        standardMinutes += standardEnd - standardStart;
        penaltyMinutes += finishMinutes - standardEnd;
      }
    } else {
      penaltyMinutes += minutesAfterMidnight;
    }
  } else {
    if (startMinutes < standardStart) {
      const beforeStandardStart = standardStart - startMinutes;
      penaltyMinutes += beforeStandardStart;

      if (finishMinutes <= standardEnd) {
        standardMinutes += finishMinutes - standardStart;
      } else {
        standardMinutes += standardEnd - standardStart;
        penaltyMinutes += finishMinutes - standardEnd;
      }
    } else if (startMinutes < standardEnd) {
      if (finishMinutes <= standardEnd) {
        standardMinutes += finishMinutes - startMinutes;
      } else {
        standardMinutes += standardEnd - startMinutes;
        penaltyMinutes += finishMinutes - standardEnd;
      }
    } else {
      penaltyMinutes += finishMinutes - startMinutes;
    }
  }

  const breakMinutes = breakHours * 60;
  const totalWorkedMinutes = standardMinutes + penaltyMinutes;

  if (totalWorkedMinutes > 0 && breakMinutes > 0) {
    const breakRatio = breakMinutes / totalWorkedMinutes;
    standardMinutes -= standardMinutes * breakRatio;
    penaltyMinutes -= penaltyMinutes * breakRatio;
  }

  return {
    standardHours: Math.max(0, standardMinutes / 60),
    penaltyHours: Math.max(0, penaltyMinutes / 60),
    holidayHours: 0
  };
}

export function determineRateType(
  dateString: string,
  startTime: string,
  finishTime: string
): RateType {
  if (!dateString || !startTime || !finishTime) {
    return 'standard';
  }

  if (isNSWPublicHoliday(dateString)) {
    return 'holiday';
  }

  const date = new Date(dateString);
  const dayOfWeek = date.getDay();

  if (dayOfWeek === 0) {
    return 'penalty';
  }

  const startHour = parseInt(startTime.split(':')[0]);
  const startMinute = parseInt(startTime.split(':')[1]);
  const finishHour = parseInt(finishTime.split(':')[0]);
  const finishMinute = parseInt(finishTime.split(':')[1]);

  const startMinutes = startHour * 60 + startMinute;
  const finishMinutes = finishHour * 60 + finishMinute;

  const standardStart = 6 * 60;
  const standardEnd = 18 * 60;

  if (startMinutes < standardStart || startMinutes >= standardEnd) {
    return 'penalty';
  }

  if (finishMinutes > standardEnd || (finishMinutes < startMinutes && finishMinutes > 0)) {
    return 'penalty';
  }

  return 'standard';
}

export function getRateValue(
  rateType: RateType,
  stdRate: number,
  penaltyRate: number,
  holidayRate: number
): number {
  switch (rateType) {
    case 'holiday':
      return holidayRate;
    case 'penalty':
      return penaltyRate;
    default:
      return stdRate;
  }
}
