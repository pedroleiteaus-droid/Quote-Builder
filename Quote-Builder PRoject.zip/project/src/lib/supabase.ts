import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Rate {
  id: string;
  service_name: string;
  role: string;
  rate_type: string | null;
  std_rate: number;
  penalty_rate: number;
  holiday_rate: number;
  item_type: 'crew' | 'equipment' | 'other' | 'custom';
  unit_type: 'hourly' | 'daily' | 'per_unit' | 'fixed';
  is_open_amount: boolean;
  category: string;
  created_at: string;
  updated_at: string;
}

export interface Quote {
  id: string;
  client_name: string;
  event_name: string;
  event_date: string;
  account_manager: string;
  account_manager_email: string;
  total_amount: number;
  created_at: string;
  updated_at: string;
}

export interface QuoteLineItem {
  id: string;
  quote_id: string;
  date: string | null;
  role: string;
  qty: number;
  start_time: string;
  finish_time: string;
  break_hours: number;
  hours: number;
  rate: number;
  total: number;
  line_order: number;
  item_type: 'crew' | 'equipment' | 'other' | 'custom';
  unit_type: 'hourly' | 'daily' | 'per_unit' | 'fixed';
  custom_item_name: string;
  custom_rate: number | null;
  created_at: string;
}

export interface AccountManager {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  is_active: boolean;
  created_at: string;
}
