import { Rate } from '../lib/supabase';

interface AddItemFormProps {
  rates: Rate[];
  itemType: 'crew' | 'equipment' | 'other' | 'custom';
  onAdd: (item: any) => void;
}

export default function AddItemForm({ rates, itemType, onAdd }: AddItemFormProps) {
  const [formData, setFormData] = useState<any>({
    date: '',
    role: '',
    qty: 1,
    start_time: '',
    finish_time: '',
    break_hours: 0,
    custom_item_name: '',
    custom_rate: ''
  });

  const filteredRates = rates.filter(r => r.item_type === itemType);
  const selectedRate = rates.find(r => r.role === formData.role);

  function handleSubmit() {
    if (itemType === 'custom') {
      if (!formData.custom_item_name || !formData.custom_rate || !formData.qty) {
        alert('Please fill in item name, rate, and quantity');
        return;
      }
    } else if (itemType === 'crew') {
      if (!formData.role || !formData.start_time || !formData.finish_time) {
        alert('Please fill in all required fields');
        return;
      }
    } else {
      if (!formData.role || !formData.qty) {
        alert('Please fill in role and quantity');
        return;
      }
    }

    onAdd({
      ...formData,
      item_type: itemType,
      rate_data: selectedRate
    });

    setFormData({
      date: '',
      role: '',
      qty: 1,
      start_time: '',
      finish_time: '',
      break_hours: 0,
      custom_item_name: '',
      custom_rate: ''
    });
  }

  return (
    <div className="mb-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
      <h4 className="text-sm font-medium text-gray-900 mb-3">
        Add {itemType === 'custom' ? 'Custom Item' : itemType.charAt(0).toUpperCase() + itemType.slice(1)}
      </h4>

      <div className="grid grid-cols-2 md:grid-cols-7 gap-3 mb-3">
        {itemType !== 'custom' && (
          <div className="col-span-2">
            <label className="block text-xs font-medium text-gray-700 mb-1">
              {itemType === 'crew' ? 'Role' : 'Item'} *
            </label>
            <select
              value={formData.role}
              onChange={(e) => setFormData({ ...formData, role: e.target.value })}
              className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Select {itemType}</option>
              {filteredRates.map((rate) => (
                <option key={rate.id} value={rate.role}>
                  {rate.service_name}
                </option>
              ))}
            </select>
          </div>
        )}

        {itemType === 'custom' && (
          <>
            <div className="col-span-2">
              <label className="block text-xs font-medium text-gray-700 mb-1">
                Item Name *
              </label>
              <input
                type="text"
                value={formData.custom_item_name}
                onChange={(e) => setFormData({ ...formData, custom_item_name: e.target.value })}
                className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="e.g., Admin Fee"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">
                Rate *
              </label>
              <input
                type="number"
                step="0.01"
                value={formData.custom_rate}
                onChange={(e) => setFormData({ ...formData, custom_rate: e.target.value })}
                className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="0.00"
              />
            </div>
          </>
        )}

        {(itemType === 'crew' || itemType === 'equipment' || itemType === 'other') && (
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1">
              Date {itemType === 'crew' ? '' : '*'}
            </label>
            <input
              type="date"
              value={formData.date}
              onChange={(e) => setFormData({ ...formData, date: e.target.value })}
              className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        )}

        <div>
          <label className="block text-xs font-medium text-gray-700 mb-1">
            Qty *
          </label>
          <input
            type="number"
            min="1"
            value={formData.qty}
            onChange={(e) => setFormData({ ...formData, qty: parseInt(e.target.value) || 1 })}
            className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        {itemType === 'crew' && (
          <>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">
                Start Time *
              </label>
              <input
                type="time"
                value={formData.start_time}
                onChange={(e) => setFormData({ ...formData, start_time: e.target.value })}
                className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">
                Finish Time *
              </label>
              <input
                type="time"
                value={formData.finish_time}
                onChange={(e) => setFormData({ ...formData, finish_time: e.target.value })}
                className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">
                Break (hrs)
              </label>
              <input
                type="number"
                step="0.25"
                min="0"
                value={formData.break_hours}
                onChange={(e) => setFormData({ ...formData, break_hours: parseFloat(e.target.value) || 0 })}
                className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </>
        )}

        {selectedRate?.is_open_amount && itemType === 'other' && (
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1">
              Amount *
            </label>
            <input
              type="number"
              step="0.01"
              value={formData.custom_rate}
              onChange={(e) => setFormData({ ...formData, custom_rate: e.target.value })}
              className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Enter amount"
            />
          </div>
        )}

        <div className="flex items-end">
          <button
            onClick={handleSubmit}
            className="w-full px-3 py-2 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 transition-colors font-medium"
          >
            Add
          </button>
        </div>
      </div>

      {selectedRate && !selectedRate.is_open_amount && (
        <div className="text-xs text-gray-600 mt-2">
          Rate: ${selectedRate.std_rate.toFixed(2)} per {selectedRate.unit_type.replace('_', ' ')}
        </div>
      )}
    </div>
  );
}

import { useState } from 'react';
