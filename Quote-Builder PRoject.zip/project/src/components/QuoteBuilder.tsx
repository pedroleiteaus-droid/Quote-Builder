import { useState, useEffect } from 'react';
import { supabase, Quote, QuoteLineItem, Rate, AccountManager } from '../lib/supabase';
import { Plus, Trash2, Save, FileText, Edit2, Check, X, Copy, Calendar } from 'lucide-react';
import QuotePDF from './QuotePDF';
import { formatDateInputToDDMMYYYY, calculateSplitHours } from '../lib/dateUtils';

interface QuoteBuilderProps {
  quoteId?: string;
  onSaved?: () => void;
}

export default function QuoteBuilder({ quoteId, onSaved }: QuoteBuilderProps) {
  const [quote, setQuote] = useState<Quote | null>(null);
  const [lineItems, setLineItems] = useState<QuoteLineItem[]>([]);
  const [rates, setRates] = useState<Rate[]>([]);
  const [accountManagers, setAccountManagers] = useState<AccountManager[]>([]);
  const [loading, setLoading] = useState(false);
  const [showPDF, setShowPDF] = useState(false);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [editingItem, setEditingItem] = useState<QuoteLineItem | null>(null);
  const [showBulkCreate, setShowBulkCreate] = useState(false);
  const [bulkCreate, setBulkCreate] = useState({
    startDate: '',
    endDate: '',
    role: '',
    qty: 1,
    start_time: '',
    finish_time: '',
    break_hours: 0
  });

  const [quoteHeader, setQuoteHeader] = useState({
    client_name: '',
    event_name: '',
    account_manager: '',
    account_manager_email: ''
  });

  const [newLineItem, setNewLineItem] = useState({
    date: '',
    role: '',
    qty: 1,
    start_time: '',
    finish_time: '',
    break_hours: 0,
    custom_rate: ''
  });

  const selectedRate = rates.find(r => r.role === newLineItem.role);
  const selectedItemType = selectedRate?.item_type || 'crew';

  useEffect(() => {
    loadRates();
    loadAccountManagers();
    if (quoteId) {
      loadQuote(quoteId);
    }
  }, [quoteId]);

  async function loadRates() {
    const { data } = await supabase
      .from('rates')
      .select('*')
      .order('role', { ascending: true });
    setRates(data || []);
  }

  async function loadAccountManagers() {
    const { data } = await supabase
      .from('account_managers')
      .select('*')
      .eq('is_active', true)
      .order('name', { ascending: true });
    setAccountManagers(data || []);
  }

  async function loadQuote(id: string) {
    setLoading(true);
    try {
      const { data: quoteData } = await supabase
        .from('quotes')
        .select('*')
        .eq('id', id)
        .maybeSingle();

      if (quoteData) {
        setQuote(quoteData);
        setQuoteHeader({
          client_name: quoteData.client_name,
          event_name: quoteData.event_name,
          account_manager: quoteData.account_manager,
          account_manager_email: quoteData.account_manager_email || ''
        });

        const { data: items } = await supabase
          .from('quote_line_items')
          .select('*')
          .eq('quote_id', id)
          .order('line_order', { ascending: true });

        setLineItems(items || []);
      }
    } catch (error) {
      console.error('Error loading quote:', error);
    } finally {
      setLoading(false);
    }
  }

  function calculateHours(startTime: string, finishTime: string, breakHours: number): number {
    if (!startTime || !finishTime) return 0;

    const [startHour, startMin] = startTime.split(':').map(Number);
    const [finishHour, finishMin] = finishTime.split(':').map(Number);

    const startMinutes = startHour * 60 + startMin;
    const finishMinutes = finishHour * 60 + finishMin;

    let totalMinutes = finishMinutes - startMinutes;
    if (totalMinutes < 0) totalMinutes += 24 * 60;

    const hours = totalMinutes / 60 - breakHours;
    return Math.max(0, hours);
  }

  function getRateForRole(role: string): number {
    const rate = rates.find((r) => r.role === role);
    return rate?.std_rate || 0;
  }

  async function generateQuoteNumber(): Promise<string> {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    const dateStr = `${year}${month}${day}`;

    const { data: quotes } = await supabase
      .from('quotes')
      .select('quote_number')
      .like('quote_number', `AR-${dateStr}-%`)
      .order('quote_number', { ascending: false })
      .limit(1);

    let sequence = 1;
    if (quotes && quotes.length > 0) {
      const lastNumber = quotes[0].quote_number.split('-')[2];
      sequence = parseInt(lastNumber) + 1;
    }

    return `AR-${dateStr}-${String(sequence).padStart(3, '0')}`;
  }

  async function handleSaveQuote() {
    if (!quoteHeader.client_name || !quoteHeader.event_name || !quoteHeader.account_manager) {
      alert('Please fill in all quote header fields');
      return;
    }

    setLoading(true);
    try {
      const totalAmount = lineItems.reduce((sum, item) => sum + item.total, 0);

      if (quote) {
        await supabase
          .from('quotes')
          .update({
            ...quoteHeader,
            total_amount: totalAmount,
            updated_at: new Date().toISOString()
          })
          .eq('id', quote.id);
      } else {
        const quoteNumber = await generateQuoteNumber();

        const { data: newQuote, error } = await supabase
          .from('quotes')
          .insert([
            {
              ...quoteHeader,
              quote_number: quoteNumber,
              client_email: quoteHeader.client_name.toLowerCase().replace(/\s+/g, '') + '@example.com',
              total_amount: totalAmount
            }
          ])
          .select()
          .single();

        if (error) throw error;
        if (newQuote) {
          setQuote(newQuote);

          if (lineItems.length > 0) {
            const itemsToInsert = lineItems.map((item, index) => ({
              quote_id: newQuote.id,
              service_name: item.role,
              hours: item.hours || 0,
              rate_per_hour: item.rate || 0,
              line_total: item.total || 0,
              sort_order: index,
              date: item.date || null,
              role: item.role,
              qty: item.qty,
              start_time: item.start_time || null,
              finish_time: item.finish_time || null,
              break_hours: item.break_hours || 0,
              rate: item.rate,
              total: item.total,
              line_order: index,
              item_type: item.item_type || null,
              unit_type: item.unit_type || null,
              custom_item_name: item.custom_item_name || null,
              custom_rate: item.custom_rate || null
            }));

            await supabase.from('quote_line_items').insert(itemsToInsert);
          }
        }
      }

      alert('Quote saved successfully! You can now generate the PDF.');
    } catch (error) {
      console.error('Error saving quote:', error);
      alert('Failed to save quote');
    } finally {
      setLoading(false);
    }
  }

  function handleAddLineItem() {
    if (!newLineItem.role) {
      alert('Please select a role/item');
      return;
    }

    const rateData = rates.find(r => r.role === newLineItem.role);
    if (!rateData) {
      alert('Rate not found');
      return;
    }

    let hours = 0;
    let rate = 0;
    let total = 0;

    if (rateData.item_type === 'crew') {
      if (!newLineItem.start_time || !newLineItem.finish_time) {
        alert('Please fill in start and finish times for crew');
        return;
      }
      if (!newLineItem.date) {
        alert('Please select a date for crew');
        return;
      }

      const splitHours = calculateSplitHours(
        newLineItem.date,
        newLineItem.start_time,
        newLineItem.finish_time,
        newLineItem.break_hours
      );

      const standardTotal = splitHours.standardHours * rateData.std_rate * newLineItem.qty;
      const penaltyTotal = splitHours.penaltyHours * rateData.penalty_rate * newLineItem.qty;
      const holidayTotal = splitHours.holidayHours * rateData.holiday_rate * newLineItem.qty;

      hours = splitHours.standardHours + splitHours.penaltyHours + splitHours.holidayHours;
      total = standardTotal + penaltyTotal + holidayTotal;
      rate = hours > 0 ? total / (hours * newLineItem.qty) : 0;
    } else if (rateData.item_type === 'equipment' || rateData.item_type === 'other') {
      if (!newLineItem.date) {
        alert('Please select a date');
        return;
      }

      if (rateData.is_open_amount) {
        if (!newLineItem.custom_rate) {
          alert('Please enter an amount for this item');
          return;
        }
        rate = parseFloat(newLineItem.custom_rate);
        total = rate * newLineItem.qty;
      } else {
        rate = rateData.std_rate;
        if (rateData.unit_type === 'per_unit') {
          total = rate * newLineItem.qty;
        } else {
          total = rate * newLineItem.qty;
        }
      }
      hours = 0;
    }

    const item: QuoteLineItem = {
      id: crypto.randomUUID(),
      quote_id: quote?.id || '',
      date: newLineItem.date || null,
      role: newLineItem.role,
      qty: newLineItem.qty,
      start_time: newLineItem.start_time || '',
      finish_time: newLineItem.finish_time || '',
      break_hours: newLineItem.break_hours || 0,
      hours,
      rate,
      total,
      line_order: lineItems.length,
      item_type: rateData.item_type,
      unit_type: rateData.unit_type,
      custom_item_name: '',
      custom_rate: newLineItem.custom_rate ? parseFloat(newLineItem.custom_rate) : null,
      created_at: new Date().toISOString()
    };

    setLineItems([...lineItems, item]);

    setNewLineItem({
      date: '',
      role: '',
      qty: 1,
      start_time: '',
      finish_time: '',
      break_hours: 0,
      custom_rate: ''
    });
  }

  function handleRemoveLineItem(index: number) {
    setLineItems(lineItems.filter((_, i) => i !== index));
  }

  function handleEditLineItem(index: number) {
    setEditingIndex(index);
    setEditingItem({ ...lineItems[index] });
  }

  function handleSaveEdit() {
    if (editingIndex === null || !editingItem) return;

    const rateData = rates.find(r => r.role === editingItem.role);
    if (!rateData) return;

    let hours = 0;
    let rate = 0;
    let total = 0;

    if (rateData.item_type === 'crew' && editingItem.start_time && editingItem.finish_time && editingItem.date) {
      const splitHours = calculateSplitHours(
        editingItem.date,
        editingItem.start_time,
        editingItem.finish_time,
        editingItem.break_hours
      );

      const standardTotal = splitHours.standardHours * rateData.std_rate * editingItem.qty;
      const penaltyTotal = splitHours.penaltyHours * rateData.penalty_rate * editingItem.qty;
      const holidayTotal = splitHours.holidayHours * rateData.holiday_rate * editingItem.qty;

      hours = splitHours.standardHours + splitHours.penaltyHours + splitHours.holidayHours;
      total = standardTotal + penaltyTotal + holidayTotal;
      rate = hours > 0 ? total / (hours * editingItem.qty) : 0;
    } else {
      hours = editingItem.hours;
      rate = editingItem.rate;
      total = rate * editingItem.qty;
    }

    const updatedItem = {
      ...editingItem,
      hours,
      rate,
      total
    };

    const newLineItems = [...lineItems];
    newLineItems[editingIndex] = updatedItem;
    setLineItems(newLineItems);
    setEditingIndex(null);
    setEditingItem(null);
  }

  function handleCancelEdit() {
    setEditingIndex(null);
    setEditingItem(null);
  }

  function handleCopyLineItem(index: number) {
    const itemToCopy = lineItems[index];
    const copiedItem = {
      id: crypto.randomUUID(),
      quote_id: itemToCopy.quote_id,
      date: itemToCopy.date,
      role: itemToCopy.role,
      qty: itemToCopy.qty,
      start_time: itemToCopy.start_time,
      finish_time: itemToCopy.finish_time,
      break_hours: itemToCopy.break_hours,
      hours: itemToCopy.hours,
      rate: itemToCopy.rate,
      total: itemToCopy.total
    };
    setLineItems([...lineItems, copiedItem]);
  }

  function handleBulkCreate() {
    if (!bulkCreate.startDate || !bulkCreate.endDate || !bulkCreate.role || !bulkCreate.start_time || !bulkCreate.finish_time) {
      alert('Please fill in all bulk create fields');
      return;
    }

    const rateData = rates.find(r => r.role === bulkCreate.role);
    if (!rateData) {
      alert('Rate not found');
      return;
    }

    const start = new Date(bulkCreate.startDate);
    const end = new Date(bulkCreate.endDate);

    if (start > end) {
      alert('Start date must be before or equal to end date');
      return;
    }

    const newItems: QuoteLineItem[] = [];
    const currentDate = new Date(start);

    while (currentDate <= end) {
      const dateString = currentDate.toISOString().split('T')[0];

      const splitHours = calculateSplitHours(
        dateString,
        bulkCreate.start_time,
        bulkCreate.finish_time,
        bulkCreate.break_hours
      );

      const standardTotal = splitHours.standardHours * rateData.std_rate * bulkCreate.qty;
      const penaltyTotal = splitHours.penaltyHours * rateData.penalty_rate * bulkCreate.qty;
      const holidayTotal = splitHours.holidayHours * rateData.holiday_rate * bulkCreate.qty;

      const hours = splitHours.standardHours + splitHours.penaltyHours + splitHours.holidayHours;
      const total = standardTotal + penaltyTotal + holidayTotal;
      const rate = hours > 0 ? total / (hours * bulkCreate.qty) : 0;

      newItems.push({
        id: crypto.randomUUID(),
        quote_id: quote?.id || '',
        date: dateString,
        role: bulkCreate.role,
        qty: bulkCreate.qty,
        start_time: bulkCreate.start_time,
        finish_time: bulkCreate.finish_time,
        break_hours: bulkCreate.break_hours,
        hours,
        rate,
        total,
        item_type: rateData.item_type,
        unit_type: rateData.unit_type,
        custom_item_name: '',
        custom_rate: null,
        created_at: new Date().toISOString()
      });
      currentDate.setDate(currentDate.getDate() + 1);
    }

    setLineItems([...lineItems, ...newItems]);
    setShowBulkCreate(false);
    setBulkCreate({
      startDate: '',
      endDate: '',
      role: '',
      qty: 1,
      start_time: '',
      finish_time: '',
      break_hours: 0
    });
  }

  const totalAmount = lineItems.reduce((sum, item) => sum + item.total, 0);

  if (showPDF && quote) {
    return (
      <QuotePDF
        quote={{ ...quote, ...quoteHeader, total_amount: totalAmount }}
        lineItems={lineItems}
        onClose={() => setShowPDF(false)}
      />
    );
  }

  return (
    <div className="bg-[#1E1E1E] rounded-lg shadow-lg p-6 border border-gray-700">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white mb-1 uppercase tracking-wide">
          {quote ? 'Edit Quote' : 'Create New Quote'}
        </h2>
        <p className="text-sm text-gray-400">
          Fill in the quote details and add line items
        </p>
      </div>

      <div className="mb-8 p-4 bg-[#2C2C2C] rounded-lg border border-[#8BC34A]/30">
        <h3 className="text-lg font-bold text-[#8BC34A] mb-4 uppercase tracking-wide">Quote Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Client Name *
            </label>
            <input
              type="text"
              value={quoteHeader.client_name}
              onChange={(e) =>
                setQuoteHeader({ ...quoteHeader, client_name: e.target.value })
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Enter client name"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Event Name *
            </label>
            <input
              type="text"
              value={quoteHeader.event_name}
              onChange={(e) =>
                setQuoteHeader({ ...quoteHeader, event_name: e.target.value })
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Enter event name"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Account Manager *
            </label>
            <select
              value={quoteHeader.account_manager}
              onChange={(e) => {
                const selectedManager = accountManagers.find(am => am.name === e.target.value);
                setQuoteHeader({
                  ...quoteHeader,
                  account_manager: e.target.value,
                  account_manager_email: selectedManager?.email || ''
                });
              }}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Select account manager</option>
              {accountManagers.map((am) => (
                <option key={am.id} value={am.name}>
                  {am.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-medium text-gray-900">Add Line Item</h3>
          <button
            onClick={() => setShowBulkCreate(!showBulkCreate)}
            className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 text-white text-sm rounded-lg hover:bg-purple-700 transition-colors"
          >
            <Calendar size={16} />
            {showBulkCreate ? 'Hide' : 'Bulk Create'}
          </button>
        </div>

        {showBulkCreate && (
          <div className="mb-4 p-4 bg-purple-50 rounded-lg border border-purple-200">
            <h4 className="text-sm font-medium text-gray-900 mb-3">Create Multiple Days</h4>
            <div className="grid grid-cols-2 md:grid-cols-7 gap-3 mb-3">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">
                  Start Date *
                </label>
                <input
                  type="date"
                  value={bulkCreate.startDate}
                  onChange={(e) => setBulkCreate({ ...bulkCreate, startDate: e.target.value })}
                  className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">
                  End Date *
                </label>
                <input
                  type="date"
                  value={bulkCreate.endDate}
                  onChange={(e) => setBulkCreate({ ...bulkCreate, endDate: e.target.value })}
                  className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">
                  Role *
                </label>
                <select
                  value={bulkCreate.role}
                  onChange={(e) => setBulkCreate({ ...bulkCreate, role: e.target.value })}
                  className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                >
                  <option value="">Select role</option>
                  {rates.map((rate) => (
                    <option key={rate.id} value={rate.role}>
                      {rate.role}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">
                  Qty *
                </label>
                <input
                  type="number"
                  min="1"
                  value={bulkCreate.qty}
                  onChange={(e) => setBulkCreate({ ...bulkCreate, qty: parseInt(e.target.value) || 1 })}
                  className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">
                  Start Time *
                </label>
                <input
                  type="time"
                  value={bulkCreate.start_time}
                  onChange={(e) => setBulkCreate({ ...bulkCreate, start_time: e.target.value })}
                  className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">
                  Finish Time *
                </label>
                <input
                  type="time"
                  value={bulkCreate.finish_time}
                  onChange={(e) => setBulkCreate({ ...bulkCreate, finish_time: e.target.value })}
                  className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">
                  Break (hrs)
                </label>
                <input
                  type="number"
                  step="0.25"
                  min="0"
                  value={bulkCreate.break_hours}
                  onChange={(e) => setBulkCreate({ ...bulkCreate, break_hours: parseFloat(e.target.value) || 0 })}
                  className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>
            </div>
            <button
              onClick={handleBulkCreate}
              className="w-full px-4 py-2 bg-purple-600 text-white text-sm rounded-lg hover:bg-purple-700 transition-colors font-medium"
            >
              Create {bulkCreate.startDate && bulkCreate.endDate ?
                `${Math.floor((new Date(bulkCreate.endDate).getTime() - new Date(bulkCreate.startDate).getTime()) / (1000 * 60 * 60 * 24)) + 1} Days` :
                'Days'}
            </button>
          </div>
        )}

        <div className="grid grid-cols-2 md:grid-cols-7 gap-3 mb-3">
          <div className="md:col-span-2">
            <label className="block text-xs font-medium text-gray-700 mb-1">
              Role / Item *
            </label>
            <select
              value={newLineItem.role}
              onChange={(e) =>
                setNewLineItem({ ...newLineItem, role: e.target.value, start_time: '', finish_time: '', break_hours: 0, custom_rate: '' })
              }
              className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Select role/item</option>
              <optgroup label="Crew">
                {rates.filter(r => r.item_type === 'crew').map((rate) => (
                  <option key={rate.id} value={rate.role}>
                    {rate.service_name}
                  </option>
                ))}
              </optgroup>
              <optgroup label="Equipment">
                {rates.filter(r => r.item_type === 'equipment').map((rate) => (
                  <option key={rate.id} value={rate.role}>
                    {rate.service_name}
                  </option>
                ))}
              </optgroup>
              <optgroup label="Other">
                {rates.filter(r => r.item_type === 'other').map((rate) => (
                  <option key={rate.id} value={rate.role}>
                    {rate.service_name}
                  </option>
                ))}
              </optgroup>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1">
              Date *
            </label>
            <input
              type="date"
              value={newLineItem.date}
              onChange={(e) =>
                setNewLineItem({ ...newLineItem, date: e.target.value })
              }
              className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1">
              Qty *
            </label>
            <input
              type="number"
              min="1"
              value={newLineItem.qty}
              onChange={(e) =>
                setNewLineItem({ ...newLineItem, qty: parseInt(e.target.value) || 1 })
              }
              className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          {selectedItemType === 'crew' && (
            <>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">
                  Start Time *
                </label>
                <input
                  type="time"
                  value={newLineItem.start_time}
                  onChange={(e) =>
                    setNewLineItem({ ...newLineItem, start_time: e.target.value })
                  }
                  className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">
                  Finish Time *
                </label>
                <input
                  type="time"
                  value={newLineItem.finish_time}
                  onChange={(e) =>
                    setNewLineItem({ ...newLineItem, finish_time: e.target.value })
                  }
                  className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">
                  Break (hrs)
                </label>
                <input
                  type="number"
                  step="0.25"
                  min="0"
                  value={newLineItem.break_hours}
                  onChange={(e) =>
                    setNewLineItem({
                      ...newLineItem,
                      break_hours: parseFloat(e.target.value) || 0
                    })
                  }
                  className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </>
          )}

          {selectedRate?.is_open_amount && selectedItemType !== 'crew' && (
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">
                Amount *
              </label>
              <input
                type="number"
                step="0.01"
                value={newLineItem.custom_rate}
                onChange={(e) =>
                  setNewLineItem({ ...newLineItem, custom_rate: e.target.value })
                }
                className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="0.00"
              />
            </div>
          )}
          <div className="flex items-end">
            <button
              onClick={handleAddLineItem}
              className="w-full px-3 py-2 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 transition-colors flex items-center justify-center gap-1"
            >
              <Plus size={16} />
              Add
            </button>
          </div>
        </div>

        {selectedRate && (
          <div className="mt-2 text-xs text-gray-600">
            <span className="font-medium">{selectedRate.service_name}</span>
            {' - '}
            {selectedRate.item_type === 'crew' ? (
              <span>Hourly rate: ${selectedRate.std_rate.toFixed(2)}/hr</span>
            ) : selectedRate.is_open_amount ? (
              <span className="text-orange-600">Variable amount - enter amount above</span>
            ) : (
              <span>
                {selectedRate.unit_type === 'daily' && `Daily rate: $${selectedRate.std_rate.toFixed(2)}/day`}
                {selectedRate.unit_type === 'per_unit' && `Per unit: $${selectedRate.std_rate.toFixed(2)}/unit`}
                {selectedRate.unit_type === 'fixed' && `Fixed rate: $${selectedRate.std_rate.toFixed(2)}`}
              </span>
            )}
          </div>
        )}
      </div>

      {lineItems.length > 0 && (
        <div className="mb-6 overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 border border-gray-200 rounded-lg">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                  Date
                </th>
                <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                  Role
                </th>
                <th className="px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase">
                  Qty
                </th>
                <th className="px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase">
                  Start
                </th>
                <th className="px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase">
                  Finish
                </th>
                <th className="px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase">
                  Break
                </th>
                <th className="px-3 py-2 text-right text-xs font-medium text-gray-500 uppercase">
                  Hours
                </th>
                <th className="px-3 py-2 text-right text-xs font-medium text-gray-500 uppercase">
                  Rate
                </th>
                <th className="px-3 py-2 text-right text-xs font-medium text-gray-500 uppercase">
                  Total
                </th>
                <th className="px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase">
                  Action
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {lineItems.map((item, index) => (
                <tr key={item.id} className={editingIndex === index ? "bg-blue-50" : "hover:bg-gray-50"}>
                  <td className="px-3 py-2 text-sm text-gray-600">
                    {editingIndex === index ? (
                      <input
                        type="date"
                        value={editingItem?.date || ''}
                        onChange={(e) => setEditingItem({ ...editingItem!, date: e.target.value })}
                        className="w-full px-2 py-1 text-sm border border-gray-300 rounded"
                      />
                    ) : (
                      item.date ? formatDateInputToDDMMYYYY(item.date) : '-'
                    )}
                  </td>
                  <td className="px-3 py-2 text-sm text-gray-900 font-medium">
                    {editingIndex === index ? (
                      <select
                        value={editingItem?.role || ''}
                        onChange={(e) => setEditingItem({ ...editingItem!, role: e.target.value })}
                        className="w-full px-2 py-1 text-sm border border-gray-300 rounded"
                      >
                        {rates.map((rate) => (
                          <option key={rate.id} value={rate.role}>
                            {rate.role}
                          </option>
                        ))}
                      </select>
                    ) : (
                      item.role
                    )}
                  </td>
                  <td className="px-3 py-2 text-sm text-center text-gray-900">
                    {editingIndex === index ? (
                      <input
                        type="number"
                        min="1"
                        value={editingItem?.qty || 1}
                        onChange={(e) => setEditingItem({ ...editingItem!, qty: parseInt(e.target.value) || 1 })}
                        className="w-full px-2 py-1 text-sm border border-gray-300 rounded"
                      />
                    ) : (
                      item.qty
                    )}
                  </td>
                  <td className="px-3 py-2 text-sm text-center text-gray-600">
                    {editingIndex === index ? (
                      <input
                        type="time"
                        value={editingItem?.start_time || ''}
                        onChange={(e) => setEditingItem({ ...editingItem!, start_time: e.target.value })}
                        className="w-full px-2 py-1 text-sm border border-gray-300 rounded"
                      />
                    ) : (
                      item.start_time
                    )}
                  </td>
                  <td className="px-3 py-2 text-sm text-center text-gray-600">
                    {editingIndex === index ? (
                      <input
                        type="time"
                        value={editingItem?.finish_time || ''}
                        onChange={(e) => setEditingItem({ ...editingItem!, finish_time: e.target.value })}
                        className="w-full px-2 py-1 text-sm border border-gray-300 rounded"
                      />
                    ) : (
                      item.finish_time
                    )}
                  </td>
                  <td className="px-3 py-2 text-sm text-center text-gray-600">
                    {editingIndex === index ? (
                      <input
                        type="number"
                        step="0.25"
                        min="0"
                        value={editingItem?.break_hours || 0}
                        onChange={(e) => setEditingItem({ ...editingItem!, break_hours: parseFloat(e.target.value) || 0 })}
                        className="w-full px-2 py-1 text-sm border border-gray-300 rounded"
                      />
                    ) : (
                      item.break_hours
                    )}
                  </td>
                  <td className="px-3 py-2 text-sm text-right text-gray-900">
                    {item.hours.toFixed(2)}
                  </td>
                  <td className="px-3 py-2 text-sm text-right text-gray-900">
                    ${item.rate.toFixed(2)}
                  </td>
                  <td className="px-3 py-2 text-sm text-right font-medium text-gray-900">
                    ${item.total.toFixed(2)}
                  </td>
                  <td className="px-3 py-2 text-center">
                    {editingIndex === index ? (
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={handleSaveEdit}
                          className="text-green-600 hover:text-green-900 transition-colors"
                          title="Save changes"
                        >
                          <Check size={16} />
                        </button>
                        <button
                          onClick={handleCancelEdit}
                          className="text-gray-600 hover:text-gray-900 transition-colors"
                          title="Cancel"
                        >
                          <X size={16} />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => handleCopyLineItem(index)}
                          className="text-green-600 hover:text-green-900 transition-colors"
                          title="Copy"
                        >
                          <Copy size={16} />
                        </button>
                        <button
                          onClick={() => handleEditLineItem(index)}
                          className="text-blue-600 hover:text-blue-900 transition-colors"
                          title="Edit"
                        >
                          <Edit2 size={16} />
                        </button>
                        <button
                          onClick={() => handleRemoveLineItem(index)}
                          className="text-red-600 hover:text-red-900 transition-colors"
                          title="Delete"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
              <tr className="bg-gray-50">
                <td colSpan={8} className="px-3 py-3 text-right text-sm text-gray-700">
                  Subtotal:
                </td>
                <td className="px-3 py-3 text-right text-sm text-gray-900">
                  ${totalAmount.toFixed(2)}
                </td>
                <td></td>
              </tr>
              <tr className="bg-gray-50">
                <td colSpan={8} className="px-3 py-3 text-right text-sm text-gray-700">
                  GST (10%):
                </td>
                <td className="px-3 py-3 text-right text-sm text-gray-900">
                  ${(totalAmount * 0.1).toFixed(2)}
                </td>
                <td></td>
              </tr>
              <tr className="bg-gray-100 font-bold">
                <td colSpan={8} className="px-3 py-3 text-right text-base text-gray-900">
                  Total Amount:
                </td>
                <td className="px-3 py-3 text-right text-lg text-gray-900">
                  ${(totalAmount * 1.1).toFixed(2)}
                </td>
                <td></td>
              </tr>
            </tbody>
          </table>
        </div>
      )}

      <div className="flex gap-3">
        <button
          onClick={handleSaveQuote}
          disabled={loading || lineItems.length === 0}
          className="inline-flex items-center gap-2 px-6 py-2 bg-[#8BC34A] text-[#1E1E1E] rounded-lg hover:bg-[#7CB342] transition-colors disabled:bg-gray-600 disabled:cursor-not-allowed font-bold uppercase tracking-wide"
        >
          <Save size={20} />
          {loading ? 'Saving...' : 'Save Quote'}
        </button>
        {quote && lineItems.length > 0 && (
          <button
            onClick={() => setShowPDF(true)}
            className="inline-flex items-center gap-2 px-6 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors font-bold uppercase tracking-wide"
          >
            <FileText size={20} />
            Generate PDF
          </button>
        )}
      </div>
    </div>
  );
}
