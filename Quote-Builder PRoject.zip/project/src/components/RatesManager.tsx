import { useState, useEffect } from 'react';
import { supabase, Rate } from '../lib/supabase';
import { Trash2, Plus, Edit2, Check, X } from 'lucide-react';

export default function RatesManager() {
  const [rates, setRates] = useState<Rate[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'crew' | 'equipment' | 'other'>('crew');
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingRate, setEditingRate] = useState<Partial<Rate> | null>(null);

  const [newRate, setNewRate] = useState({
    service_name: '',
    role: '',
    item_type: 'crew' as const,
    unit_type: 'hourly' as const,
    std_rate: '',
    penalty_rate: '',
    holiday_rate: '',
    is_open_amount: false,
    category: ''
  });

  useEffect(() => {
    loadRates();
  }, []);

  async function loadRates() {
    try {
      const { data, error } = await supabase
        .from('rates')
        .select('*')
        .order('category', { ascending: true })
        .order('service_name', { ascending: true });

      if (error) throw error;
      setRates(data || []);
    } catch (error) {
      console.error('Error loading rates:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleAddRate() {
    if (!newRate.service_name) {
      alert('Please fill in Item Name');
      return;
    }

    if (activeTab === 'crew' && (!newRate.std_rate || !newRate.penalty_rate || !newRate.holiday_rate)) {
      alert('Please fill in all three rates (Standard, Penalty, Holiday)');
      return;
    }

    if (activeTab !== 'crew' && !newRate.is_open_amount && !newRate.std_rate) {
      alert('Please fill in the rate');
      return;
    }

    try {
      const { error } = await supabase.from('rates').insert([
        {
          service_name: newRate.service_name,
          role: newRate.service_name,
          item_type: newRate.item_type,
          unit_type: newRate.unit_type,
          std_rate: parseFloat(newRate.std_rate) || 0,
          penalty_rate: parseFloat(newRate.penalty_rate) || 0,
          holiday_rate: parseFloat(newRate.holiday_rate) || 0,
          rate_per_hour: parseFloat(newRate.std_rate) || 0,
          is_open_amount: newRate.is_open_amount,
          category: newRate.category || newRate.item_type.charAt(0).toUpperCase() + newRate.item_type.slice(1)
        }
      ]);

      if (error) throw error;

      setNewRate({
        service_name: '',
        role: '',
        item_type: 'crew',
        unit_type: 'hourly',
        std_rate: '',
        penalty_rate: '',
        holiday_rate: '',
        is_open_amount: false,
        category: ''
      });
      setShowAddForm(false);
      loadRates();
    } catch (error) {
      console.error('Error adding rate:', error);
      alert('Failed to add rate');
    }
  }

  async function handleUpdateRate() {
    if (!editingRate || !editingId) {
      console.log('Missing editingRate or editingId', { editingRate, editingId });
      return;
    }

    console.log('Updating rate:', { editingRate, editingId, activeTab });

    try {
      const updateData: any = {
        std_rate: Number(editingRate.std_rate),
        is_open_amount: editingRate.is_open_amount || false
      };

      if (activeTab === 'crew') {
        updateData.penalty_rate = Number(editingRate.penalty_rate);
        updateData.holiday_rate = Number(editingRate.holiday_rate);
        updateData.rate_per_hour = Number(editingRate.std_rate);
      } else {
        updateData.penalty_rate = Number(editingRate.penalty_rate) || 0;
        updateData.holiday_rate = Number(editingRate.holiday_rate) || 0;
      }

      console.log('Update data:', updateData);

      const { data, error } = await supabase
        .from('rates')
        .update(updateData)
        .eq('id', editingId)
        .select();

      console.log('Update result:', { data, error });

      if (error) {
        console.error('Supabase error:', error);
        throw error;
      }

      setEditingId(null);
      setEditingRate(null);
      await loadRates();
    } catch (error) {
      console.error('Error updating rate:', error);
      alert('Failed to update rate: ' + (error as any).message);
    }
  }

  async function handleDeleteRate(id: string) {
    if (!confirm('Are you sure you want to delete this rate?')) return;

    try {
      const { error } = await supabase.from('rates').delete().eq('id', id);

      if (error) throw error;
      loadRates();
    } catch (error) {
      console.error('Error deleting rate:', error);
      alert('Failed to delete rate');
    }
  }

  const filteredRates = rates.filter(rate => rate.item_type === activeTab);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-gray-500">Loading rates...</div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-semibold text-gray-900">Rates Management</h2>
          <p className="text-sm text-gray-600 mt-1">
            Manage rates for crew, equipment, and other items
          </p>
        </div>
        <button
          onClick={() => {
            setNewRate({
              ...newRate,
              item_type: activeTab,
              unit_type: activeTab === 'crew' ? 'hourly' : activeTab === 'equipment' ? 'daily' : 'daily'
            });
            setShowAddForm(true);
          }}
          className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus size={20} />
          Add New Rate
        </button>
      </div>

      <div className="mb-6 border-b border-gray-200">
        <nav className="flex space-x-8">
          <button
            onClick={() => setActiveTab('crew')}
            className={`py-3 px-1 border-b-2 font-medium text-sm transition-colors ${
              activeTab === 'crew'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Crew (Hourly)
          </button>
          <button
            onClick={() => setActiveTab('equipment')}
            className={`py-3 px-1 border-b-2 font-medium text-sm transition-colors ${
              activeTab === 'equipment'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Equipment (Daily)
          </button>
          <button
            onClick={() => setActiveTab('other')}
            className={`py-3 px-1 border-b-2 font-medium text-sm transition-colors ${
              activeTab === 'other'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Other Items
          </button>
        </nav>
      </div>

      {showAddForm && (
        <div className="mb-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            Add New {activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} Rate
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
            <div className={activeTab === 'crew' ? 'md:col-span-4' : 'md:col-span-2'}>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {activeTab === 'crew' ? 'Role' : 'Item'} Name *
              </label>
              <input
                type="text"
                value={newRate.service_name}
                onChange={(e) => setNewRate({ ...newRate, service_name: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder={activeTab === 'crew' ? 'e.g., Warehouse Crew' : 'e.g., 3T Truck hire Daily'}
              />
            </div>

            {activeTab === 'crew' && (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Standard Rate ($/hr) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={newRate.std_rate}
                    onChange={(e) => setNewRate({ ...newRate, std_rate: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="0.00"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Penalty Rate ($/hr) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={newRate.penalty_rate}
                    onChange={(e) => setNewRate({ ...newRate, penalty_rate: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="0.00"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Holiday Rate ($/hr) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={newRate.holiday_rate}
                    onChange={(e) => setNewRate({ ...newRate, holiday_rate: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="0.00"
                  />
                </div>
              </>
            )}

            {activeTab !== 'crew' && (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Unit Type *
                  </label>
                  <select
                    value={newRate.unit_type}
                    onChange={(e) => setNewRate({ ...newRate, unit_type: e.target.value as any })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    {activeTab === 'equipment' && <option value="daily">Daily</option>}
                    {activeTab === 'other' && (
                      <>
                        <option value="per_unit">Per Unit</option>
                        <option value="daily">Daily</option>
                        <option value="fixed">Fixed</option>
                      </>
                    )}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {newRate.is_open_amount ? 'Default Rate (Optional)' : 'Rate *'}
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={newRate.std_rate}
                    onChange={(e) => setNewRate({ ...newRate, std_rate: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="0.00"
                    disabled={newRate.is_open_amount}
                  />
                </div>
                {activeTab === 'other' && (
                  <div className="flex items-end pb-2">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={newRate.is_open_amount}
                        onChange={(e) => setNewRate({ ...newRate, is_open_amount: e.target.checked, std_rate: '' })}
                        className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                      />
                      <span className="text-sm text-gray-700">Variable Amount</span>
                    </label>
                  </div>
                )}
              </>
            )}
          </div>
          <div className="flex gap-3">
            <button
              onClick={handleAddRate}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Add Rate
            </button>
            <button
              onClick={() => {
                setShowAddForm(false);
                setNewRate({
                  service_name: '',
                  role: '',
                  item_type: 'crew',
                  unit_type: 'hourly',
                  std_rate: '',
                  penalty_rate: '',
                  holiday_rate: '',
                  is_open_amount: false,
                  category: ''
                });
              }}
              className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {filteredRates.length === 0 ? (
        <div className="text-center py-12 text-gray-500">
          No {activeTab} rates found. Click "Add New Rate" to create one.
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {activeTab === 'crew' ? 'Role' : 'Item'} Name
                </th>
                {activeTab !== 'crew' && (
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Unit Type
                  </th>
                )}
                {activeTab === 'crew' ? (
                  <>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Standard ($/hr)
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Penalty ($/hr)
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Holiday ($/hr)
                    </th>
                  </>
                ) : (
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Rate
                  </th>
                )}
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredRates.map((rate) => (
                <tr key={rate.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {rate.service_name}
                  </td>
                  {activeTab !== 'crew' && (
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 capitalize">
                      {rate.unit_type.replace('_', ' ')}
                    </td>
                  )}
                  {activeTab === 'crew' ? (
                    <>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right">
                        {editingId === rate.id ? (
                          <input
                            type="number"
                            step="0.01"
                            value={editingRate?.std_rate || 0}
                            onChange={(e) => setEditingRate(editingRate ? { ...editingRate, std_rate: parseFloat(e.target.value) || 0 } : null)}
                            className="w-24 px-2 py-1 text-right border border-gray-300 rounded"
                          />
                        ) : (
                          `$${rate.std_rate.toFixed(2)}`
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right">
                        {editingId === rate.id ? (
                          <input
                            type="number"
                            step="0.01"
                            value={editingRate?.penalty_rate || 0}
                            onChange={(e) => setEditingRate(editingRate ? { ...editingRate, penalty_rate: parseFloat(e.target.value) || 0 } : null)}
                            className="w-24 px-2 py-1 text-right border border-gray-300 rounded"
                          />
                        ) : (
                          `$${rate.penalty_rate.toFixed(2)}`
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right">
                        {editingId === rate.id ? (
                          <input
                            type="number"
                            step="0.01"
                            value={editingRate?.holiday_rate || 0}
                            onChange={(e) => setEditingRate(editingRate ? { ...editingRate, holiday_rate: parseFloat(e.target.value) || 0 } : null)}
                            className="w-24 px-2 py-1 text-right border border-gray-300 rounded"
                          />
                        ) : (
                          `$${rate.holiday_rate.toFixed(2)}`
                        )}
                      </td>
                    </>
                  ) : (
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right">
                      {editingId === rate.id ? (
                        <input
                          type="number"
                          step="0.01"
                          value={editingRate?.std_rate || 0}
                          onChange={(e) => setEditingRate(editingRate ? { ...editingRate, std_rate: parseFloat(e.target.value) || 0 } : null)}
                          className="w-24 px-2 py-1 text-right border border-gray-300 rounded"
                        />
                      ) : rate.is_open_amount ? (
                        <span className="text-gray-400 italic">Variable</span>
                      ) : (
                        `$${rate.std_rate.toFixed(2)}`
                      )}
                    </td>
                  )}
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm font-medium">
                    {editingId === rate.id ? (
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={handleUpdateRate}
                          className="text-green-600 hover:text-green-900"
                          title="Save"
                        >
                          <Check size={18} />
                        </button>
                        <button
                          onClick={() => {
                            setEditingId(null);
                            setEditingRate(null);
                          }}
                          className="text-gray-600 hover:text-gray-900"
                          title="Cancel"
                        >
                          <X size={18} />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center gap-2">
                        {!rate.is_open_amount && (
                          <button
                            onClick={() => {
                              setEditingId(rate.id);
                              setEditingRate(rate);
                            }}
                            className="text-blue-600 hover:text-blue-900"
                            title="Edit"
                          >
                            <Edit2 size={18} />
                          </button>
                        )}
                        <button
                          onClick={() => handleDeleteRate(rate.id)}
                          className="text-red-600 hover:text-red-900"
                          title="Delete"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
