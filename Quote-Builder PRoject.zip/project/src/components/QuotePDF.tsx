import { Quote, QuoteLineItem, Rate } from '../lib/supabase';
import { X, Download } from 'lucide-react';
import { useRef, useEffect, useState } from 'react';
import { formatDateInputToDDMMYYYY, calculateSplitHours } from '../lib/dateUtils';
import { supabase } from '../lib/supabase';

interface QuotePDFProps {
  quote: Quote;
  lineItems: QuoteLineItem[];
  onClose: () => void;
}

interface RateSummary {
  role: string;
  unitType: string;
  stdRate: number;
  penaltyRate: number;
  holidayRate: number;
  stdHours: number;
  penaltyHours: number;
  holidayHours: number;
  cost: number;
}

export default function QuotePDF({ quote, lineItems, onClose }: QuotePDFProps) {
  const pdfRef = useRef<HTMLDivElement>(null);
  const [rates, setRates] = useState<Rate[]>([]);

  useEffect(() => {
    loadRates();
  }, []);

  async function loadRates() {
    const { data } = await supabase
      .from('rates')
      .select('*')
      .order('role', { ascending: true });
    setRates(data || []);
  }

  function handlePrint() {
    const clientName = quote.client_name || 'Client';
    const eventName = quote.event_name || 'Event';
    const fileName = `${clientName} - ${eventName} - AR Quote Sheet`;

    const originalTitle = document.title;
    document.title = fileName;

    window.print();

    setTimeout(() => {
      document.title = originalTitle;
    }, 1000);
  }

  const formatDate = (dateString: string | null | undefined) => {
    if (!dateString) return '-';
    try {
      const date = new Date(dateString);
      const day = String(date.getDate()).padStart(2, '0');
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const year = date.getFullYear();
      return `${day}/${month}/${year}`;
    } catch (e) {
      return '-';
    }
  };

  const formatDateWithDay = (dateString: string | null | undefined) => {
    if (!dateString) return '-';
    try {
      const date = new Date(dateString);
      const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      const day = days[date.getDay()];
      const dateNum = String(date.getDate()).padStart(2, '0');
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const year = String(date.getFullYear()).slice(-2);
      return `${day}, ${dateNum}/${month}/${year}`;
    } catch (e) {
      return '-';
    }
  };

  const rateSummaries: RateSummary[] = [];
  const roleMap = new Map<string, RateSummary>();

  lineItems.forEach((item) => {
    const rateData = rates.find(r => r.role === item.role);
    if (!rateData) return;

    if (!roleMap.has(item.role)) {
      roleMap.set(item.role, {
        role: item.role,
        unitType: rateData.item_type === 'crew' ? 'Hourly' : rateData.unit_type === 'daily' ? 'Daily' : 'Per Unit',
        stdRate: rateData.std_rate,
        penaltyRate: rateData.penalty_rate,
        holidayRate: rateData.holiday_rate,
        stdHours: 0,
        penaltyHours: 0,
        holidayHours: 0,
        cost: 0
      });
    }

    const summary = roleMap.get(item.role)!;

    if (rateData.item_type === 'crew' && item.date) {
      const splitHours = calculateSplitHours(
        item.date,
        item.start_time || '',
        item.finish_time || '',
        item.break_hours || 0
      );

      summary.stdHours += splitHours.standardHours * item.qty;
      summary.penaltyHours += splitHours.penaltyHours * item.qty;
      summary.holidayHours += splitHours.holidayHours * item.qty;
    } else {
      summary.stdHours += item.qty;
    }

    summary.cost += item.total;
  });

  roleMap.forEach(summary => rateSummaries.push(summary));

  const crewItems = lineItems.filter(item => {
    const rateData = rates.find(r => r.role === item.role);
    return rateData?.item_type === 'crew';
  });

  const equipmentItems = lineItems.filter(item => {
    const rateData = rates.find(r => r.role === item.role);
    return rateData?.item_type === 'equipment' || rateData?.item_type === 'other';
  });

  const subtotal = quote.total_amount || 0;
  const gst = subtotal * 0.1;
  const total = subtotal + gst;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-[1000px] w-full max-h-[90vh] overflow-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between print:hidden">
          <h2 className="text-xl font-semibold text-gray-900">Quote Preview</h2>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-2 px-4 py-2 bg-[#8BC34A] text-[#1E1E1E] rounded-lg hover:bg-[#7CB342] transition-colors font-bold"
            >
              <Download size={18} />
              Print / Save PDF
            </button>
            <button
              onClick={onClose}
              className="p-2 text-gray-500 hover:text-gray-700 transition-colors"
            >
              <X size={24} />
            </button>
          </div>
        </div>

        <div ref={pdfRef} className="p-8 bg-white print:p-4" id="pdf-content">
          <div className="max-w-full mx-auto bg-white">
            <div className="flex items-start justify-between mb-6">
              <div>
                <div className="text-xs mb-1"><strong>Client:</strong> {quote.client_name || '-'}</div>
                <div className="text-xs mb-1"><strong>Job/Event:</strong> {quote.event_name || '-'}</div>
                <div className="text-xs mb-1"><strong>Date:</strong> {formatDate(quote.created_at)}</div>
                <div className="text-xs mb-1"><strong>Prepared by:</strong> {quote.account_manager || '-'}</div>
                <div className="text-xs"><strong>Email:</strong> {quote.account_manager_email || '-'}</div>
              </div>
              <div>
                <img
                  src="/Allranks_logo1.png"
                  alt="All Ranks Logo"
                  className="h-24 w-auto"
                />
              </div>
            </div>

            <div className="mb-4">
              <h1 className="text-base font-bold text-gray-900 text-center">Draft Quote Sheet</h1>
            </div>

            <div className="mb-4 overflow-x-auto">
              <table className="min-w-full text-xs border border-gray-900">
                <thead>
                  <tr className="bg-white border-b border-gray-900">
                    <th className="px-2 py-1 text-left font-bold border-r border-gray-900">Date</th>
                    <th className="px-2 py-1 text-left font-bold border-r border-gray-900">Rate Code - ROLE</th>
                    <th className="px-2 py-1 text-center font-bold border-r border-gray-900">Qty</th>
                    <th className="px-2 py-1 text-center font-bold border-r border-gray-900">Start</th>
                    <th className="px-2 py-1 text-center font-bold border-r border-gray-900">Finish</th>
                    <th className="px-2 py-1 text-center font-bold border-r border-gray-900">Std</th>
                    <th className="px-2 py-1 text-center font-bold border-r border-gray-900">Penalty</th>
                    <th className="px-2 py-1 text-center font-bold border-r border-gray-900">Holiday</th>
                    <th className="px-2 py-1 text-center font-bold">Hours</th>
                  </tr>
                </thead>
                <tbody>
                  {crewItems.map((item, index) => {
                    const splitHours = item.date ? calculateSplitHours(
                      item.date,
                      item.start_time || '',
                      item.finish_time || '',
                      item.break_hours || 0
                    ) : { standardHours: 0, penaltyHours: 0, holidayHours: 0 };

                    return (
                      <tr key={item.id} className="border-b border-gray-300">
                        <td className="px-2 py-1 border-r border-gray-300">
                          {item.date ? formatDateWithDay(item.date) : '-'}
                        </td>
                        <td className="px-2 py-1 border-r border-gray-300">{item.role}</td>
                        <td className="px-2 py-1 text-center border-r border-gray-300">{item.qty}</td>
                        <td className="px-2 py-1 text-center border-r border-gray-300">{item.start_time || '-'}</td>
                        <td className="px-2 py-1 text-center border-r border-gray-300">{item.finish_time || '-'}</td>
                        <td className="px-2 py-1 text-center border-r border-gray-300">
                          {splitHours.standardHours.toFixed(2)}
                        </td>
                        <td className="px-2 py-1 text-center border-r border-gray-300">
                          {splitHours.penaltyHours.toFixed(2)}
                        </td>
                        <td className="px-2 py-1 text-center border-r border-gray-300">
                          {splitHours.holidayHours.toFixed(2)}
                        </td>
                        <td className="px-2 py-1 text-center">
                          {(splitHours.standardHours + splitHours.penaltyHours + splitHours.holidayHours).toFixed(2)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="mb-4">
              <table className="min-w-full text-xs border border-gray-900">
                <thead>
                  <tr className="bg-white border-b border-gray-900">
                    <th className="px-2 py-1 text-left font-bold border-r border-gray-900">Total By Rate</th>
                    <th className="px-2 py-1 text-center font-bold border-r border-gray-900"></th>
                    <th className="px-2 py-1 text-center font-bold border-r border-gray-900">Std Rate</th>
                    <th className="px-2 py-1 text-center font-bold border-r border-gray-900">Penalty Rate</th>
                    <th className="px-2 py-1 text-center font-bold border-r border-gray-900">Holiday Rate</th>
                    <th className="px-2 py-1 text-center font-bold border-r border-gray-900">Std Hours</th>
                    <th className="px-2 py-1 text-center font-bold border-r border-gray-900">Penalty Hours</th>
                    <th className="px-2 py-1 text-center font-bold border-r border-gray-900">Holiday Hours</th>
                    <th className="px-2 py-1 text-right font-bold">Cost</th>
                  </tr>
                </thead>
                <tbody>
                  {rateSummaries.map((summary, index) => (
                    <tr key={index} className="border-b border-gray-300">
                      <td className="px-2 py-1 border-r border-gray-300">{summary.role}</td>
                      <td className="px-2 py-1 text-center border-r border-gray-300">{summary.unitType}</td>
                      <td className="px-2 py-1 text-center border-r border-gray-300">
                        ${summary.stdRate.toFixed(2)}
                      </td>
                      <td className="px-2 py-1 text-center border-r border-gray-300">
                        {summary.penaltyRate > 0 ? `$${summary.penaltyRate.toFixed(2)}` : ''}
                      </td>
                      <td className="px-2 py-1 text-center border-r border-gray-300">
                        {summary.holidayRate > 0 ? `$${summary.holidayRate.toFixed(2)}` : ''}
                      </td>
                      <td className="px-2 py-1 text-center border-r border-gray-300">
                        {summary.stdHours.toFixed(2)}
                      </td>
                      <td className="px-2 py-1 text-center border-r border-gray-300">
                        {summary.penaltyHours.toFixed(2)}
                      </td>
                      <td className="px-2 py-1 text-center border-r border-gray-300">
                        {summary.holidayHours.toFixed(2)}
                      </td>
                      <td className="px-2 py-1 text-right">${summary.cost.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex justify-end mb-6">
              <div className="w-64">
                <table className="w-full text-xs">
                  <tbody>
                    <tr>
                      <td className="py-1 pr-4 text-right font-bold">Subtotal</td>
                      <td className="py-1 text-right font-bold">${subtotal.toFixed(2)}</td>
                    </tr>
                    <tr>
                      <td className="py-1 pr-4 text-right font-bold">GST</td>
                      <td className="py-1 text-right font-bold">${gst.toFixed(2)}</td>
                    </tr>
                    <tr className="border-t-2 border-gray-900">
                      <td className="py-1 pr-4 text-right font-bold">Total</td>
                      <td className="py-1 text-right font-bold">${total.toFixed(2)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-8 text-xs">
              <div>
                <div className="font-bold mb-2">Notes:</div>
                <div className="space-y-1">
                  <div>4h min call applies to any shift</div>
                  <div>This quote is an estimate only. Charges will be based on the actual hours worked by each crew member.</div>
                  <div>Penalty rates apply from 6 pm to 6 am and Sundays</div>
                  <div className="font-bold mt-2">Cancelation fee policy:</div>
                  <div>Less than 24h - Full shift to be charged</div>
                  <div>Between 48h - 24h - 4h call will be charged</div>
                  <div>No charges with more than 48h notice</div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-bold">All Ranks Events Pty Ltd</div>
                <div>ABN:69 627 228 068</div>
                <div>Unit 18, 9 Bermill Street, Rockdale</div>
                <div>NSW, 2216</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @media print {
          @page {
            size: A4;
            margin: 15mm;
          }

          @page {
            margin-top: 0;
            margin-bottom: 0;
          }

          html, body {
            margin: 0;
            padding: 0;
          }

          body * {
            visibility: hidden;
          }

          .print\\:hidden {
            display: none !important;
          }

          #pdf-content,
          #pdf-content * {
            visibility: visible;
          }

          #pdf-content {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
          }

          .fixed {
            position: relative;
          }

          .overflow-auto {
            overflow: visible;
          }

          table {
            page-break-inside: auto;
          }

          tr {
            page-break-inside: avoid;
            page-break-after: auto;
          }
        }
      `}</style>
    </div>
  );
}
