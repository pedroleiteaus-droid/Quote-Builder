/*
  # Update Schema for AllRanks Quote Builder

  ## Overview
  This migration updates the existing schema to match the AllRanks Quote Sheet requirements.
  It modifies tables to support the exact structure from columns A-I of the AR Quote Sheet.

  ## Changes

  ### 1. Update `rates` table
  - Add missing columns: role, rate_type, std_rate, penalty_rate, holiday_rate
  - Keep existing data structure compatible

  ### 2. Update `quotes` table
  - Add account_manager field
  - Rename fields to match AllRanks terminology
  - Keep total_amount for calculated totals

  ### 3. Update `quote_line_items` table
  - Add all required fields from AR Quote Sheet columns A-I
  - Add date, role, qty, start_time, finish_time, break_hours
  - Rename fields to match terminology
  - Add line_order for proper sequencing

  ## Important Notes
  1. All changes are backwards compatible with existing data
  2. New columns have appropriate defaults
  3. Maintains existing RLS policies
*/

-- Update rates table to support AllRanks structure
DO $$
BEGIN
  -- Add role column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'rates' AND column_name = 'role'
  ) THEN
    ALTER TABLE rates ADD COLUMN role text;
  END IF;

  -- Add rate_type column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'rates' AND column_name = 'rate_type'
  ) THEN
    ALTER TABLE rates ADD COLUMN rate_type text;
  END IF;

  -- Add std_rate column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'rates' AND column_name = 'std_rate'
  ) THEN
    ALTER TABLE rates ADD COLUMN std_rate numeric(10,2) DEFAULT 0;
  END IF;

  -- Add penalty_rate column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'rates' AND column_name = 'penalty_rate'
  ) THEN
    ALTER TABLE rates ADD COLUMN penalty_rate numeric(10,2) DEFAULT 0;
  END IF;

  -- Add holiday_rate column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'rates' AND column_name = 'holiday_rate'
  ) THEN
    ALTER TABLE rates ADD COLUMN holiday_rate numeric(10,2) DEFAULT 0;
  END IF;
END $$;

-- Update quotes table to support AllRanks structure
DO $$
BEGIN
  -- Add account_manager column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'quotes' AND column_name = 'account_manager'
  ) THEN
    ALTER TABLE quotes ADD COLUMN account_manager text DEFAULT '';
  END IF;

  -- Add total_amount as alias for total if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'quotes' AND column_name = 'total_amount'
  ) THEN
    ALTER TABLE quotes ADD COLUMN total_amount numeric(10,2) DEFAULT 0;
  END IF;
END $$;

-- Update quote_line_items table to match AR Quote Sheet columns A-I
DO $$
BEGIN
  -- Add date column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'quote_line_items' AND column_name = 'date'
  ) THEN
    ALTER TABLE quote_line_items ADD COLUMN date date;
  END IF;

  -- Add role column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'quote_line_items' AND column_name = 'role'
  ) THEN
    ALTER TABLE quote_line_items ADD COLUMN role text DEFAULT '';
  END IF;

  -- Add qty column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'quote_line_items' AND column_name = 'qty'
  ) THEN
    ALTER TABLE quote_line_items ADD COLUMN qty integer DEFAULT 1;
  END IF;

  -- Add start_time column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'quote_line_items' AND column_name = 'start_time'
  ) THEN
    ALTER TABLE quote_line_items ADD COLUMN start_time text DEFAULT '';
  END IF;

  -- Add finish_time column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'quote_line_items' AND column_name = 'finish_time'
  ) THEN
    ALTER TABLE quote_line_items ADD COLUMN finish_time text DEFAULT '';
  END IF;

  -- Add break_hours column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'quote_line_items' AND column_name = 'break_hours'
  ) THEN
    ALTER TABLE quote_line_items ADD COLUMN break_hours numeric(4,2) DEFAULT 0;
  END IF;

  -- Add rate column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'quote_line_items' AND column_name = 'rate'
  ) THEN
    ALTER TABLE quote_line_items ADD COLUMN rate numeric(10,2) DEFAULT 0;
  END IF;

  -- Add total column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'quote_line_items' AND column_name = 'total'
  ) THEN
    ALTER TABLE quote_line_items ADD COLUMN total numeric(10,2) DEFAULT 0;
  END IF;

  -- Add line_order column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'quote_line_items' AND column_name = 'line_order'
  ) THEN
    ALTER TABLE quote_line_items ADD COLUMN line_order integer DEFAULT 0;
  END IF;
END $$;

-- Create index for line_order if it doesn't exist
CREATE INDEX IF NOT EXISTS idx_quote_line_items_order ON quote_line_items(quote_id, line_order);

-- Create index for rates role if it doesn't exist
CREATE INDEX IF NOT EXISTS idx_rates_role ON rates(role);