/*
  # Update Rates from All Ranks Rate Card

  ## Overview
  Updates all rates to match the official All Ranks Events Rate Card A

  ## Changes

  ### 1. Update Crew Rates (Hourly)
  - Warehouse Crew: $47.25 / $57.75 / $94.50
  - General Site Crew: $52.50 / $67.50 / $105.00
  - Skilled Crew / 3T Driver: $57.75 / $72.50 / $115.50
  - Forklift Driver: $63.00 / $73.50 / $126.00
  - EWP Operator (YC): $63.00 / $73.50 / $126.00
  - Boom Lift / Telehandler Op: $73.50 / $89.25 / $147.00
  - HR/MR Truck Driver: $63.00 / $84.50 / $126.00
  - Site Supervisor / Lead Crew: $65.00 / $75.00 / $130.00
  - Site Manager: $70.00 / $85.00 / $140.00
  - Set Builder / Carpenter: $70.00 / $85.00 / $140.00
  - Rigger: $90.00 / $115.00 / $180.00

  ### 2. Update Equipment Rates (Daily)
  - 3T Truck hire Daily: $275.00
  - 9T Truck hire Daily: $675.00
  - Van/UTE Hire: $210.00
  - Trailer Boom Lift: $630.00
  - Ladder 1.8m: $42.00

  ### 3. Update Other Items
  - Food Allowances: $75.00 (Daily)
  - Extra Km: $0.45 (per unit)
  - Fuel Allowance: $500.00 (per unit)
  - Accommodation: $250.00 (Daily)
  - Warehousing 4x std pallets: $300.00 (Fixed)
  - Flights: $1,000.00 (Fixed)

  ### 4. Add New Account Managers
  - Henry Figueira
  - Pedro Leite
  - Arthur Corbo Forlin
  - Yngrid Haggar

  ## Important Notes
  1. Clears existing rates and recreates with correct values
  2. Adds new account managers if they don't exist
*/

-- Delete existing rates to avoid duplicates
DELETE FROM rates;

-- Insert Crew rates with correct values
INSERT INTO rates (service_name, role, item_type, unit_type, rate_per_hour, std_rate, penalty_rate, holiday_rate, category, is_open_amount)
VALUES
  ('Warehouse Crew', 'Warehouse Crew', 'crew', 'hourly', 47.25, 47.25, 57.75, 94.50, 'Crew', false),
  ('General Site Crew', 'General Site Crew', 'crew', 'hourly', 52.50, 52.50, 67.50, 105.00, 'Crew', false),
  ('Skilled Crew / 3T Driver', 'Skilled Crew / 3T Driver', 'crew', 'hourly', 57.75, 57.75, 72.50, 115.50, 'Crew', false),
  ('Forklift Driver', 'Forklift Driver', 'crew', 'hourly', 63.00, 63.00, 73.50, 126.00, 'Crew', false),
  ('EWP Operator (YC)', 'EWP Operator (YC)', 'crew', 'hourly', 63.00, 63.00, 73.50, 126.00, 'Crew', false),
  ('Boom Lift / Telehandler Op', 'Boom Lift / Telehandler Op', 'crew', 'hourly', 73.50, 73.50, 89.25, 147.00, 'Crew', false),
  ('HR/MR Truck Driver', 'HR/MR Truck Driver', 'crew', 'hourly', 63.00, 63.00, 84.50, 126.00, 'Crew', false),
  ('Site Supervisor / Lead Crew', 'Site Supervisor / Lead Crew', 'crew', 'hourly', 65.00, 65.00, 75.00, 130.00, 'Crew', false),
  ('Site Manager', 'Site Manager', 'crew', 'hourly', 70.00, 70.00, 85.00, 140.00, 'Crew', false),
  ('Set Builder / Carpenter', 'Set Builder / Carpenter', 'crew', 'hourly', 70.00, 70.00, 85.00, 140.00, 'Crew', false),
  ('Rigger', 'Rigger', 'crew', 'hourly', 90.00, 90.00, 115.00, 180.00, 'Crew', false);

-- Insert Equipment rates
INSERT INTO rates (service_name, role, item_type, unit_type, rate_per_hour, std_rate, penalty_rate, holiday_rate, category, is_open_amount)
VALUES
  ('3T Truck hire Daily', '3T Truck hire Daily', 'equipment', 'daily', 275.00, 275.00, 0, 0, 'Equipment', false),
  ('9T Truck hire Daily', '9T Truck hire Daily', 'equipment', 'daily', 675.00, 675.00, 0, 0, 'Equipment', false),
  ('Van/UTE Hire', 'Van/UTE Hire', 'equipment', 'daily', 210.00, 210.00, 0, 0, 'Equipment', false),
  ('Trailer Boom Lift', 'Trailer Boom Lift', 'equipment', 'daily', 630.00, 630.00, 0, 0, 'Equipment', false),
  ('Ladder 1.8m', 'Ladder 1.8m', 'equipment', 'daily', 42.00, 42.00, 0, 0, 'Equipment', false);

-- Insert Other items
INSERT INTO rates (service_name, role, item_type, unit_type, rate_per_hour, std_rate, penalty_rate, holiday_rate, category, is_open_amount)
VALUES
  ('Food Allowances', 'Food Allowances', 'other', 'daily', 75.00, 75.00, 0, 0, 'Other', false),
  ('Extra Km', 'Extra Km', 'other', 'per_unit', 0.45, 0.45, 0, 0, 'Other', false),
  ('Fuel Allowance', 'Fuel Allowance', 'other', 'per_unit', 500.00, 500.00, 0, 0, 'Other', false),
  ('Accommodation', 'Accommodation', 'other', 'daily', 250.00, 250.00, 0, 0, 'Other', false),
  ('Warehousing 4x std pallets', 'Warehousing 4x std pallets', 'other', 'fixed', 300.00, 300.00, 0, 0, 'Other', false),
  ('Flights', 'Flights', 'other', 'fixed', 1000.00, 1000.00, 0, 0, 'Other', false);

-- Add new account managers if they don't exist
INSERT INTO account_managers (name, email, phone, is_active)
VALUES
  ('Lucas Canabarro', 'lucas@allranks.com.au', '0406 150 062', true),
  ('Henry Figueira', 'henry@allranks.com.au', NULL, true),
  ('Pedro Leite', 'pedro@allranks.com.au', NULL, true),
  ('Arthur Corbo Forlin', 'arthur@allranks.com.au', NULL, true),
  ('Yngrid Haggar', 'yngrid@allranks.com.au', NULL, true)
ON CONFLICT (email) DO NOTHING;