/*
  # Auto-set Quote Date to Sydney Timezone

  ## Overview
  This migration modifies the quotes table to automatically set the event_date
  to the current date in Sydney, Australia timezone when a quote is created.

  ## Changes Made

  ### Quotes Table
  - Change event_date to use default value of current date in Sydney timezone (Australia/Sydney)
  - The date is set automatically at creation time and stored in the database

  ## Important Notes
  1. Uses PostgreSQL's timezone support to ensure accurate Sydney time
  2. The date is calculated at the time of quote creation
  3. Format: YYYY-MM-DD (date only, no time component)
*/

-- Set default value for event_date to current date in Sydney timezone
ALTER TABLE quotes 
  ALTER COLUMN event_date SET DEFAULT (NOW() AT TIME ZONE 'Australia/Sydney')::date;