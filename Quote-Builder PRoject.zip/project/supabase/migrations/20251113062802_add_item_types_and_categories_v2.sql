/*
  # Add Item Types and Categories Support

  ## Overview
  This migration adds support for different types of items in the quote system:
  - Crew items (hourly rates with start/finish times)
  - Equipment items (fixed daily rates)
  - Other items (variable amounts, open pricing)
  - Custom items (user-defined name, price, quantity)

  ## Changes

  ### 1. Update `rates` table
  - Add `item_type` column: 'crew', 'equipment', 'other', 'custom'
  - Add `unit_type` column: 'hourly', 'daily', 'per_unit', 'fixed'
  - Add `is_open_amount` column: boolean for items with variable pricing
  - Modify structure to support both time-based and fixed-rate items

  ### 2. Update `quote_line_items` table
  - Add `item_type` column to identify the type of line item
  - Add `unit_type` column for pricing calculation
  - Add `hours` column if not exists
  - Add `custom_item_name` for custom items
  - Add `custom_rate` for items with open/custom pricing

  ## Important Notes
  1. Backwards compatible with existing crew-based rates
  2. Existing rates default to 'crew' type with 'hourly' unit
  3. New indexes for efficient querying by type
*/

-- Update rates table to support different item types
DO $$
BEGIN
  -- Add item_type column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'rates' AND column_name = 'item_type'
  ) THEN
    ALTER TABLE rates ADD COLUMN item_type text DEFAULT 'crew';
  END IF;

  -- Add unit_type column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'rates' AND column_name = 'unit_type'
  ) THEN
    ALTER TABLE rates ADD COLUMN unit_type text DEFAULT 'hourly';
  END IF;

  -- Add is_open_amount column for variable pricing
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'rates' AND column_name = 'is_open_amount'
  ) THEN
    ALTER TABLE rates ADD COLUMN is_open_amount boolean DEFAULT false;
  END IF;
END $$;

-- Update quote_line_items table
DO $$
BEGIN
  -- Add item_type column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'quote_line_items' AND column_name = 'item_type'
  ) THEN
    ALTER TABLE quote_line_items ADD COLUMN item_type text DEFAULT 'crew';
  END IF;

  -- Add unit_type column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'quote_line_items' AND column_name = 'unit_type'
  ) THEN
    ALTER TABLE quote_line_items ADD COLUMN unit_type text DEFAULT 'hourly';
  END IF;

  -- Add hours column if not exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'quote_line_items' AND column_name = 'hours'
  ) THEN
    ALTER TABLE quote_line_items ADD COLUMN hours numeric(10,2) DEFAULT 0;
  END IF;

  -- Add custom_item_name for custom items
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'quote_line_items' AND column_name = 'custom_item_name'
  ) THEN
    ALTER TABLE quote_line_items ADD COLUMN custom_item_name text DEFAULT '';
  END IF;

  -- Add custom_rate for items with open/custom pricing
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'quote_line_items' AND column_name = 'custom_rate'
  ) THEN
    ALTER TABLE quote_line_items ADD COLUMN custom_rate numeric(10,2);
  END IF;
END $$;

-- Create indexes for efficient querying
CREATE INDEX IF NOT EXISTS idx_rates_item_type ON rates(item_type);
CREATE INDEX IF NOT EXISTS idx_rates_unit_type ON rates(unit_type);
CREATE INDEX IF NOT EXISTS idx_quote_line_items_item_type ON quote_line_items(item_type);

-- Insert predefined crew rates
INSERT INTO rates (service_name, role, item_type, unit_type, rate_per_hour, std_rate, category, is_open_amount)
VALUES
  ('Warehouse Crew', 'Warehouse Crew', 'crew', 'hourly', 0, 0, 'Crew', false),
  ('General Site Crew', 'General Site Crew', 'crew', 'hourly', 0, 0, 'Crew', false),
  ('Skilled Crew / 3T Driver', 'Skilled Crew / 3T Driver', 'crew', 'hourly', 0, 0, 'Crew', false),
  ('Forklift Driver', 'Forklift Driver', 'crew', 'hourly', 0, 0, 'Crew', false),
  ('EWP Operator (YC)', 'EWP Operator (YC)', 'crew', 'hourly', 0, 0, 'Crew', false),
  ('Boom Lift / Telehandler Op', 'Boom Lift / Telehandler Op', 'crew', 'hourly', 0, 0, 'Crew', false),
  ('HR/MR Truck Driver', 'HR/MR Truck Driver', 'crew', 'hourly', 0, 0, 'Crew', false),
  ('Site Supervisor / Lead Crew', 'Site Supervisor / Lead Crew', 'crew', 'hourly', 0, 0, 'Crew', false),
  ('Site Manager', 'Site Manager', 'crew', 'hourly', 0, 0, 'Crew', false),
  ('Set Builder / Carpenter', 'Set Builder / Carpenter', 'crew', 'hourly', 0, 0, 'Crew', false),
  ('Rigger', 'Rigger', 'crew', 'hourly', 0, 0, 'Crew', false)
ON CONFLICT DO NOTHING;

-- Insert equipment rates (fixed daily)
INSERT INTO rates (service_name, role, item_type, unit_type, rate_per_hour, std_rate, category, is_open_amount)
VALUES
  ('3T Truck hire Daily', '3T Truck hire Daily', 'equipment', 'daily', 0, 0, 'Equipment', false),
  ('9T Truck hire Daily', '9T Truck hire Daily', 'equipment', 'daily', 0, 0, 'Equipment', false),
  ('Van/UTE Hire', 'Van/UTE Hire', 'equipment', 'daily', 0, 0, 'Equipment', false),
  ('Trailer Boom Lift', 'Trailer Boom Lift', 'equipment', 'daily', 0, 0, 'Equipment', false),
  ('Ladder 1.8m', 'Ladder 1.8m', 'equipment', 'daily', 0, 0, 'Equipment', false)
ON CONFLICT DO NOTHING;

-- Insert other items (variable pricing)
INSERT INTO rates (service_name, role, item_type, unit_type, rate_per_hour, std_rate, category, is_open_amount)
VALUES
  ('Extra Km - Per unit', 'Extra Km - Per unit', 'other', 'per_unit', 0.30, 0.30, 'Other', false),
  ('Fuel Allowance', 'Fuel Allowance', 'other', 'daily', 0, 0, 'Other', true),
  ('Accommodation', 'Accommodation', 'other', 'daily', 0, 0, 'Other', true),
  ('Warehousing 4x std pallets', 'Warehousing 4x std pallets', 'other', 'fixed', 300, 300, 'Other', false),
  ('Food Allowances', 'Food Allowances', 'other', 'daily', 0, 0, 'Other', true)
ON CONFLICT DO NOTHING;