/*
  # Add account manager email to quotes table

  1. Changes
    - Add `account_manager_email` column to `quotes` table to store the email address of the account manager
  
  2. Notes
    - This allows quotes to retain the correct email even if account manager data changes later
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'quotes' AND column_name = 'account_manager_email'
  ) THEN
    ALTER TABLE quotes ADD COLUMN account_manager_email text DEFAULT '';
  END IF;
END $$;