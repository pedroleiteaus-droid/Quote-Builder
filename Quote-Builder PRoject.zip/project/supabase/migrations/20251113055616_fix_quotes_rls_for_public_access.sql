/*
  # Fix Quotes and Quote Line Items RLS for Public Access

  ## Overview
  This migration updates Row Level Security policies for quotes and quote_line_items tables
  to allow anonymous (public) access since the application does not have authentication.

  ## Changes Made

  ### Quotes Table
  - Drop all existing authenticated-only policies
  - Create new policies allowing public access for all operations
  - Remove created_by column requirement (will be nullable)

  ### Quote Line Items Table
  - Drop all existing authenticated-only policies
  - Create new policies allowing public access for all operations

  ## Security Notes
  - This is an internal tool without authentication requirements
  - All operations are granted to anonymous users
  - Can add authentication layer later if needed
*/

-- Make created_by nullable in quotes table
ALTER TABLE quotes ALTER COLUMN created_by DROP NOT NULL;

-- Drop existing policies on quotes table
DROP POLICY IF EXISTS "Users can view own quotes" ON quotes;
DROP POLICY IF EXISTS "Users can create quotes" ON quotes;
DROP POLICY IF EXISTS "Users can update own quotes" ON quotes;
DROP POLICY IF EXISTS "Users can delete own quotes" ON quotes;

-- Create new public policies for quotes
CREATE POLICY "Public users can view all quotes"
  ON quotes FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Public users can create quotes"
  ON quotes FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Public users can update quotes"
  ON quotes FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Public users can delete quotes"
  ON quotes FOR DELETE
  TO anon, authenticated
  USING (true);

-- Drop existing policies on quote_line_items table
DROP POLICY IF EXISTS "Users can view line items of own quotes" ON quote_line_items;
DROP POLICY IF EXISTS "Users can create line items for own quotes" ON quote_line_items;
DROP POLICY IF EXISTS "Users can update line items of own quotes" ON quote_line_items;
DROP POLICY IF EXISTS "Users can delete line items of own quotes" ON quote_line_items;

-- Create new public policies for quote_line_items
CREATE POLICY "Public users can view all line items"
  ON quote_line_items FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Public users can create line items"
  ON quote_line_items FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Public users can update line items"
  ON quote_line_items FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Public users can delete line items"
  ON quote_line_items FOR DELETE
  TO anon, authenticated
  USING (true);