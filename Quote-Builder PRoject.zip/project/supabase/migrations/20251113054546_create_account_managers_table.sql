/*
  # Create Account Managers Table

  ## Overview
  This migration creates a table to store Account Manager information with their contact details.

  ## New Tables

  ### `account_managers`
  - `id` (uuid, primary key) - Unique identifier
  - `name` (text) - Full name of the account manager
  - `email` (text) - Email address
  - `phone` (text, nullable) - Phone number
  - `is_active` (boolean) - Whether the AM is currently active
  - `created_at` (timestamptz) - Record creation timestamp

  ## Security
  - Enable RLS on the table
  - Authenticated users can read all account managers
  - Authenticated users can manage account managers

  ## Important Notes
  1. This table provides a centralized list of AMs for quote assignment
  2. Email addresses are stored for future communication features
*/

-- Create account_managers table
CREATE TABLE IF NOT EXISTS account_managers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL UNIQUE,
  phone text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Create index on email
CREATE INDEX IF NOT EXISTS idx_account_managers_email ON account_managers(email);

-- Enable Row Level Security
ALTER TABLE account_managers ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for account_managers table
CREATE POLICY "Authenticated users can view account managers"
  ON account_managers FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert account managers"
  ON account_managers FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update account managers"
  ON account_managers FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete account managers"
  ON account_managers FOR DELETE
  TO authenticated
  USING (true);