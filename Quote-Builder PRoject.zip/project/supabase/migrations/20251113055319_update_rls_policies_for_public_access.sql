/*
  # Update RLS Policies for Public Access

  ## Overview
  This migration updates Row Level Security policies to allow anonymous (public) access
  for reading data from rates and account_managers tables. This is necessary because
  the application does not have authentication implemented.

  ## Changes Made

  ### Rates Table
  - Drop existing authenticated-only SELECT policies
  - Create new policy allowing public (anon) users to view all rates

  ### Account Managers Table
  - Drop existing authenticated-only SELECT policy
  - Create new policy allowing public (anon) users to view active account managers

  ## Security Notes
  - Read access is granted to anonymous users for operational data
  - Write operations still require authentication for security
  - These are operational reference tables with no sensitive data
*/

-- Drop existing SELECT policies on rates table
DROP POLICY IF EXISTS "Authenticated users can view active rates" ON rates;
DROP POLICY IF EXISTS "Authenticated users can view all rates" ON rates;

-- Create new public SELECT policy for rates
CREATE POLICY "Public users can view all rates"
  ON rates FOR SELECT
  TO anon, authenticated
  USING (true);

-- Drop existing SELECT policy on account_managers table
DROP POLICY IF EXISTS "Authenticated users can view account managers" ON account_managers;

-- Create new public SELECT policy for account_managers
CREATE POLICY "Public users can view active account managers"
  ON account_managers FOR SELECT
  TO anon, authenticated
  USING (is_active = true);